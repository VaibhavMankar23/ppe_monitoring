import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { Page } from "../components/layout/Shell";
import { CameraTile } from "../components/live/CameraTile";
import { isProblem } from "../components/live/status";
import { Button, cx, Empty, Icon, Notice, Panel, Segmented, Skeleton, Tag, type IconName } from "../components/ui";
import { api, jpegDataUrl, type AnalyticsQuery } from "../lib/api";
import { fmtAgo, fmtInt, fmtPct, violationLabel } from "../lib/format";
import { href, navigateWith } from "../lib/router";
import { useAuth } from "../state/auth";
import { useMonitor } from "../state/monitor";
import type { AnalyticsSummary, CameraStats, Heatmap, PpeCount, TimePoint, Violation } from "../types";

const DAY = 86_400;
const startOfDay = (d = new Date()) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 1000;
const tz = () => -new Date().getTimezoneOffset();
const q = (days: number, end = Date.now() / 1000): AnalyticsQuery => ({ start: startOfDay() - (days - 1) * DAY, end, tz: tz() });

const ITEM_ICON: Record<string, IconName> = {
  helmet: "helmet", vest: "vest", gloves: "gloves", mask: "mask", goggles: "goggles", boots: "boots", ear_protection: "ear",
  phone_use: "phone", restricted_area: "restricted",
};

interface Figures {
  today: AnalyticsSummary;
  week: AnalyticsSummary;
  camsToday: CameraStats[];
  camsWeek: CameraStats[];
  ppe: PpeCount[];
  heat: Heatmap;
}

/** Today's, the last 7 days' and the last 4 weeks' figures, refreshed every minute. */
function useFigures(enabled: boolean) {
  const [data, setData] = useState<Figures | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    const load = async () => {
      try {
        const [today, week, camsToday, camsWeek, ppe, heat] = await Promise.all([
          api.analytics.summary(q(1)), api.analytics.summary(q(7)), api.analytics.byCamera(q(1)),
          api.analytics.byCamera(q(7)), api.analytics.byPpe(q(7)), api.analytics.heatmap(q(28)),
        ]);
        if (alive) { setData({ today, week, camsToday, camsWeek, ppe, heat }); setError(null); }
      } catch (e) {
        if (alive) setError(e instanceof Error ? e.message : "Couldn't load the figures.");
      }
    };
    void load();
    const t = window.setInterval(() => void load(), 60_000);
    return () => { alive = false; window.clearInterval(t); };
  }, [enabled]);
  return { data, error };
}

function useTrend(enabled: boolean, days: number) {
  const [points, setPoints] = useState<TimePoint[] | null>(null);
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    setPoints(null);
    api.analytics.timeseries(q(days), "day").then((t) => alive && setPoints(t.points)).catch(() => alive && setPoints([]));
    return () => { alive = false; };
  }, [enabled, days]);
  return points;
}

/** The newest incidents nobody has reviewed yet, kept live. */
function useOpenIncidents(enabled: boolean) {
  const { onViolation, onViolationUpdate } = useMonitor();
  const [items, setItems] = useState<Violation[] | null>(null);
  const [total, setTotal] = useState(0);
  const [fresh, setFresh] = useState<number | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    api.violations.list({ review: "unreviewed", limit: 6 })
      .then((p) => { if (alive) { setItems(p.items); setTotal(p.total); } })
      .catch(() => alive && setFailed(true));
    const offNew = onViolation((v) => {
      setItems((xs) => [v, ...(xs ?? []).filter((x) => x.id !== v.id)].slice(0, 6));
      setTotal((n) => n + 1);
      setFresh(v.id);
    });
    const offUpd = onViolationUpdate((u) => setItems((xs) => xs?.map((x) => (x.id === u.id ? { ...x, state: u.state, last_seen: u.last_seen, missing: u.missing ?? x.missing } : x)) ?? xs));
    return () => { alive = false; offNew(); offUpd(); };
  }, [enabled, onViolation, onViolationUpdate]);
  return { items, total, failed, fresh };
}

// ------------------------------------------------------------------ pieces

function Card({ title, sub, actions, children, className, bodyClass }:
  { title: string; sub?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; bodyClass?: string }) {
  return (
    <Panel className={cx("flex flex-col", className)}>
      <div className="flex items-center gap-3 px-[22px] pt-[18px]">
        <div className="min-w-0">
          <h3 className="text-[15px] font-semibold tracking-tight">{title}</h3>
          {sub && <div className="mt-px text-[12.5px] text-ink-3">{sub}</div>}
        </div>
        {actions && <div className="ml-auto flex items-center gap-2">{actions}</div>}
      </div>
      <div className={cx("min-h-0 flex-1", bodyClass ?? "px-[22px] pt-[18px] pb-[22px]")}>{children}</div>
    </Panel>
  );
}

function Kpi({ icon, label, value, small, foot, children }: { icon: IconName; label: string; value: ReactNode; small?: ReactNode; foot?: ReactNode; children?: ReactNode }) {
  return (
    <Panel className="px-5 py-[18px]">
      <div className="flex items-center gap-2 text-[13px] font-medium text-ink-3"><Icon name={icon} size={16} />{label}</div>
      <div className="num mt-2.5 mb-1.5 flex items-baseline gap-2 text-[30px] leading-[1.1] font-semibold tracking-[-0.035em]">
        {value}{small && <small className="text-sm font-medium tracking-normal text-ink-3">{small}</small>}
      </div>
      {foot && <div className="flex flex-wrap items-center gap-2 text-[12.5px] text-ink-3">{foot}</div>}
      {children}
    </Panel>
  );
}

/** Ring gauge: the rate as an arc, the target as a tick across the ring. */
function Gauge({ value, target }: { value: number | null; target: number }) {
  const R = 78, C = 2 * Math.PI * R, f = Math.max(0, Math.min(1, value ?? 0)), a = target * 2 * Math.PI;
  return (
    <div className="relative size-[178px] shrink-0">
      <svg viewBox="0 0 178 178" className="size-full -rotate-90" aria-hidden="true">
        <defs><linearGradient id="gauge" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="var(--color-data-2)" /><stop offset="1" stopColor="var(--color-data)" /></linearGradient></defs>
        <circle cx="89" cy="89" r={R} fill="none" stroke="var(--color-sunken)" strokeWidth="12" />
        {value !== null && <circle cx="89" cy="89" r={R} fill="none" stroke="url(#gauge)" strokeWidth="12" strokeLinecap="round" strokeDasharray={`${C * f} ${C}`} />}
        <line x1={89 + (R - 10) * Math.cos(a)} y1={89 + (R - 10) * Math.sin(a)} x2={89 + (R + 10) * Math.cos(a)} y2={89 + (R + 10) * Math.sin(a)}
          stroke="var(--color-ink)" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <b className="num block text-[40px] leading-none font-semibold tracking-[-0.04em]">
            {value === null ? "–" : (value * 100).toFixed(1)}<span className="text-xl text-ink-3">{value === null ? "" : "%"}</span>
          </b>
          <span className="text-xs text-ink-3">target {fmtPct(target, 0)}</span>
        </div>
      </div>
    </div>
  );
}

function Trend({ points, target }: { points: TimePoint[]; target: number }) {
  const pts = points.filter((p) => p.compliance_rate !== null) as (TimePoint & { compliance_rate: number })[];
  if (pts.length < 2) return <p className="m-auto py-10 text-[13px] text-ink-3">Not enough days with workers checked to draw a trend yet.</p>;
  const W = 600, H = 170, vals = pts.map((p) => p.compliance_rate * 100);
  const lo = Math.floor(Math.min(target * 100 - 2, ...vals) - 1), hi = Math.ceil(Math.max(target * 100 + 1, ...vals) + 0.5);
  const X = (i: number) => 34 + (i * (W - 48)) / (pts.length - 1), Y = (v: number) => 10 + ((hi - v) / (hi - lo)) * (H - 34);
  const d = vals.map((v, i) => `${i ? "L" : "M"}${X(i)},${Y(v)}`).join(" ");
  const ticks = [lo, Math.round((lo + hi) / 2), hi].filter((v, i, a) => a.indexOf(v) === i);
  const every = Math.ceil(pts.length / 8);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="mt-auto block h-auto w-full pt-2.5" role="img" aria-label={`Compliance rate per day, last ${pts.length} days`}>
      <defs><linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--color-data)" stopOpacity=".22" /><stop offset="1" stopColor="var(--color-data)" stopOpacity="0" /></linearGradient></defs>
      {ticks.map((v) => <g key={v}><line x1="34" x2={W - 14} y1={Y(v)} y2={Y(v)} stroke="var(--color-line)" /><text x="0" y={Y(v) + 4} className="fill-ink-4 font-mono text-[11px]">{v}%</text></g>)}
      <line x1="34" x2={W - 14} y1={Y(target * 100)} y2={Y(target * 100)} stroke="var(--color-ink-4)" strokeDasharray="4 4" />
      <path d={`${d} L${X(pts.length - 1)},${H - 24} L${X(0)},${H - 24} Z`} fill="url(#trendFill)" />
      <path d={d} fill="none" stroke="var(--color-data)" strokeWidth="2.2" strokeLinejoin="round" />
      <circle cx={X(pts.length - 1)} cy={Y(vals[vals.length - 1])} r="4.5" fill="var(--color-surface)" stroke="var(--color-data)" strokeWidth="2.2" />
      {pts.map((p, i) => (i % every === 0 || i === pts.length - 1) && (
        <text key={p.t} x={X(i)} y={H - 6} textAnchor="middle" className="fill-ink-4 font-mono text-[11px]">{new Date(p.t * 1000).getDate()}</text>
      ))}
    </svg>
  );
}

function HourHeat({ heat }: { heat: Heatmap }) {
  const steps = ["var(--color-sunken)", "color-mix(in oklab,var(--color-data) 22%,var(--color-surface))", "color-mix(in oklab,var(--color-data) 45%,var(--color-surface))",
    "color-mix(in oklab,var(--color-data) 70%,var(--color-surface))", "var(--color-data)"];
  const step = (v: number) => (v <= 0 || heat.max <= 0 ? 0 : Math.min(4, Math.max(1, Math.ceil((v / heat.max) * 4))));
  let peak = { d: 0, h: 0, v: -1 };
  heat.grid.forEach((row, d) => row.forEach((v, h) => { if (v > peak.v) peak = { d, h, v }; }));
  return (
    <>
      <div className="grid grid-cols-[30px_repeat(24,minmax(0,1fr))] gap-[3px] font-mono text-[10.5px] text-ink-4" role="img" aria-label="Incidents by hour and weekday">
        {heat.grid.map((row, d) => [
          <span key={`l${d}`} className="flex items-center">{heat.days[d]?.slice(0, 3)}</span>,
          ...row.map((v, h) => <span key={`${d}-${h}`} title={`${heat.days[d]} ${String(h).padStart(2, "0")}:00 · ${v} incident${v === 1 ? "" : "s"}`}
            className="aspect-square rounded-[3px]" style={{ background: steps[step(v)] }} />),
        ])}
        <span />
        {Array.from({ length: 24 }, (_, h) => <span key={h} className="text-center">{h % 6 === 0 ? String(h).padStart(2, "0") : ""}</span>)}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11.5px] text-ink-3">
        Fewer {steps.map((c) => <i key={c} className="inline-block h-2 w-3.5 rounded-sm" style={{ background: c }} />)} More
        {peak.v > 0 && <span className="ml-auto">Busiest: {heat.days[peak.d]?.slice(0, 3)} {String(peak.h).padStart(2, "0")}:00</span>}
      </div>
    </>
  );
}

function IncidentRow({ v, fresh }: { v: Violation; fresh: boolean }) {
  const ongoing = v.state === "ongoing";
  return (
    <button type="button" onClick={() => navigateWith("incidents", { id: v.id })}
      className={cx("grid w-full grid-cols-[52px_minmax(0,1fr)_auto] items-center gap-[13px] border-t border-line px-[22px] py-3 text-left hover:bg-surface-2", fresh && "animate-[flash_2.6s]")}>
      <img src={jpegDataUrl(v.thumbnail)} alt="" className="size-[52px] rounded-[9px] bg-stage object-cover" />
      <div className="min-w-0">
        <div className="truncate text-[13.5px] leading-tight font-semibold">{v.missing.map(violationLabel).join(", ")}</div>
        <div className="truncate text-[12.5px] text-ink-3">{v.stream_name} · worker <span className="num">#{v.track_id}</span></div>
      </div>
      <div className="grid justify-items-end gap-[5px] text-xs text-ink-3">
        {ongoing ? <Tag tone="bad"><span className="size-1.5 rounded-full bg-current" />Ongoing</Tag> : <Tag>Open</Tag>}
        <span>{fmtAgo(v.timestamp)}</span>
      </div>
    </button>
  );
}

const greeting = () => { const h = new Date().getHours(); return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"; };
const rateColor = (r: number, target: number) => (r < target - 0.025 ? "var(--color-bad)" : r < target ? "var(--color-warn)" : "var(--color-data)");

// ------------------------------------------------------------------ page

export function OverviewPage() {
  const { can, user } = useAuth();
  const { connected, streams, info } = useMonitor();
  const canAnalytics = can("analytics:view");
  const canIncidents = can("violations:view");
  const { data, error } = useFigures(canAnalytics);
  const [days, setDays] = useState<"7" | "14" | "30">("14");
  const trend = useTrend(canAnalytics, Number(days));
  const open = useOpenIncidents(canIncidents);
  const [, tick] = useState(0);
  useEffect(() => { const t = window.setInterval(() => tick((n) => n + 1), 15_000); return () => window.clearInterval(t); }, []);
  const openCamera = useCallback((id: string) => navigateWith("monitoring", { camera: id }), []);

  const live = useMemo(() => ({
    workers: streams.reduce((n, s) => n + s.workers, 0),
    bad: streams.reduce((n, s) => n + s.violations, 0),
    live: streams.filter((s) => s.status === "live").length,
    problems: streams.filter(isProblem),
    violating: streams.filter((s) => s.violations > 0).length,
  }), [streams]);

  const target = data?.week.compliance_target ?? 0.95;
  const today = data?.today;
  const rate = today?.compliance_rate ?? null;
  const delta = rate !== null && today?.previous_compliance_rate != null ? (rate - today.previous_compliance_rate) * 100 : null;
  const lowest = (data?.camsToday ?? []).filter((c) => c.compliance_rate !== null).sort((a, b) => a.compliance_rate! - b.compliance_rate!)[0];
  const attention = live.problems.length + live.violating;
  const headline = rate === null ? "No workers checked yet today."
    : rate >= target ? `On target, ${((rate - target) * 100).toFixed(1)} pts above ${fmtPct(target, 0)}.`
    : `${((target - rate) * 100).toFixed(1)} pts under target.${lowest && lowest.compliance_rate! < target ? ` ${lowest.stream_name} is lowest today at ${fmtPct(lowest.compliance_rate)}.` : ""}`;
  const ongoing = open.items?.filter((v) => v.state === "ongoing").length ?? 0;
  const ppeRows = (data?.ppe ?? []).filter((p) => p.count > 0).sort((a, b) => b.count - a.count).slice(0, 6);
  const ppeMax = Math.max(1, ...ppeRows.map((p) => p.count));
  const camRows = (data?.camsWeek ?? []).filter((c) => c.compliance_rate !== null).sort((a, b) => a.compliance_rate! - b.compliance_rate!);
  const lo = Math.min(0.85, ...camRows.map((c) => c.compliance_rate! - 0.02));
  const pos = (r: number) => `${Math.max(2, ((r - lo) / (1 - lo)) * 100)}%`;
  const avgDay = data?.week.avg_violations_per_day ?? null;

  return (
    <Page wide={false} title={`${greeting()}, ${user?.username ?? ""}`}
      description={<>
        <span className="mr-2 inline-flex items-center gap-2 text-ink-2"><span className={cx("inline-block size-[7px] rounded-full", connected ? "live-ping bg-[#34d27f]" : "bg-bad")} />
          {connected ? "Live" : "Reconnecting"} · {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}</span>
        {rate !== null && (rate >= target ? "The plant is on track today." : "Compliance is below target today.")}
        {attention > 0 ? ` ${attention} camera${attention === 1 ? " needs" : "s need"} a look.` : streams.length ? " Every camera is clear." : ""}
      </>}
      actions={<>
        {canAnalytics && <a href={href("reports")} className="inline-flex h-[38px] items-center gap-2 rounded-[10px] border border-line-strong bg-surface px-[15px] text-[13.5px] font-semibold text-ink no-underline shadow-[var(--sh-xs)] hover:border-ink-4"><Icon name="download" size={16} />Reports</a>}
        {canIncidents && (
          <button type="button" onClick={() => navigateWith("incidents", {})}
            className="inline-flex h-[38px] items-center gap-2 rounded-[10px] border border-pri bg-pri px-[15px] text-[13.5px] font-semibold text-pri-ink shadow-[var(--sh-xs)] hover:bg-pri-hover">
            Review {open.items ? fmtInt(open.total) : ""} incidents <Icon name="arrowRight" size={16} />
          </button>
        )}
      </>}>
      {!connected && info && <Notice tone="bad" title="Connection to the server lost" className="mb-5">Live figures are frozen. Reconnecting automatically.</Notice>}
      {error && <Notice tone="bad" title="Couldn't load the figures" className="mb-5">{error}</Notice>}

      {/* ---- hero: gauge + trend ---- */}
      {canAnalytics && (
        <div className="mb-5 grid gap-5 xl:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
          <Panel className="relative grid items-center gap-[30px] overflow-hidden px-7 py-[26px] sm:grid-cols-[auto_minmax(0,1fr)]">
            <span aria-hidden="true" className="absolute inset-x-0 top-0 h-[3px] bg-[linear-gradient(90deg,var(--color-brand),var(--color-data)_45%,transparent_85%)]" />
            {data ? <Gauge value={rate} target={target} /> : <Skeleton className="size-[178px] rounded-full" />}
            <div className="min-w-0">
              <h2 className="text-[13px] font-medium tracking-normal text-ink-3">Compliance today</h2>
              <div className="mt-1.5 mb-1 max-w-[30ch] text-xl leading-snug font-semibold tracking-[-0.02em]">{data ? headline : <Skeleton className="h-14 w-72" />}</div>
              {delta !== null && (
                <span className={cx("inline-flex items-center gap-0.5 text-[12.5px] font-semibold", delta >= 0 ? "text-ok" : "text-bad")}>
                  <Icon name={delta >= 0 ? "arrowUp" : "arrowDown"} size={13} />{Math.abs(delta).toFixed(1)} pts vs previous day
                </span>
              )}
              <div className="mt-[18px] flex flex-wrap gap-[22px]">
                <div><span className="block text-xs text-ink-3">Workers checked</span><b className="num text-lg font-semibold tracking-tight">{today ? fmtInt(today.workers_seen) : "–"}</b></div>
                <div><span className="block text-xs text-ink-3">Flagged</span><b className="num text-lg font-semibold tracking-tight">{today ? fmtInt(today.workers_flagged) : "–"}</b></div>
                <div><span className="block text-xs text-ink-3">Alert precision, 7 days</span><b className="num text-lg font-semibold tracking-tight">{data?.week.review.precision != null ? fmtPct(data.week.review.precision, 0) : "–"}</b></div>
              </div>
            </div>
          </Panel>
          <Panel className="flex flex-col px-6 pt-[22px] pb-3.5">
            <div className="flex items-start gap-3">
              <div><h3 className="text-[15px] font-semibold tracking-tight">Compliance trend</h3><span className="text-[12.5px] text-ink-3">Last {days} days · dashed line is the {fmtPct(target, 0)} target</span></div>
              <div className="ml-auto"><Segmented size="sm" label="Trend range" value={days} onChange={setDays}
                options={[{ value: "7", label: "7D" }, { value: "14", label: "14D" }, { value: "30", label: "30D" }]} /></div>
            </div>
            {trend === null ? <Skeleton className="mt-4 h-40" /> : <Trend points={trend} target={target} />}
          </Panel>
        </div>
      )}

      {/* ---- KPIs ---- */}
      <div className="mb-5 grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {canIncidents && (
          <Kpi icon="incidents" label="Open incidents" value={open.items ? fmtInt(open.total) : "–"} small={ongoing ? `${ongoing} ongoing` : undefined}
            foot={open.items?.length ? <><Tag tone="warn">Oldest shown {fmtAgo(open.items[open.items.length - 1].timestamp)}</Tag>not reviewed yet</> : <Tag tone="ok">Queue clear</Tag>} />
        )}
        <Kpi icon="person" label="Workers in view" value={fmtInt(live.workers)} small="now"
          foot={<><Tag tone={live.bad ? "bad" : "ok"}>{live.bad} non-compliant</Tag>across {live.live} camera{live.live === 1 ? "" : "s"}</>} />
        <Kpi icon="monitoring" label="Cameras online" value={live.live} small={`/ ${streams.length}`}
          foot={live.problems.length ? <><Tag tone="warn">{live.problems[0].name}</Tag>{live.problems.length > 1 ? `+${live.problems.length - 1} more not delivering` : "not delivering"}</>
            : <Tag tone="ok">All delivering</Tag>} />
        <Kpi icon="clock" label="Recorded today" value={fmtInt(info?.violations_today ?? 0)} small="incidents"
          foot={avgDay !== null ? `7-day average ${avgDay.toFixed(1)} a day` : undefined}>
          {avgDay !== null && avgDay > 0 && (
            <div className="mt-3 h-[5px] overflow-hidden rounded-[3px] bg-sunken">
              <i className="block h-full rounded-[3px]" style={{ width: `${Math.min(100, ((info?.violations_today ?? 0) / (avgDay * 1.5)) * 100)}%`, background: (info?.violations_today ?? 0) > avgDay ? "var(--color-warn)" : "var(--color-data)" }} />
            </div>
          )}
        </Kpi>
      </div>

      {/* ---- live floor + needs attention ---- */}
      <div className={cx("mb-5 grid gap-5", canIncidents && "xl:grid-cols-[minmax(0,1.6fr)_minmax(340px,1fr)]")}>
        <Card title="Live floor" sub="Select a camera to open its live view"
          actions={<a href={href("monitoring")} className="inline-flex h-8 items-center gap-1.5 rounded-lg px-3 text-[13px] font-semibold text-ink-2 no-underline hover:bg-sunken">Open wall<Icon name="arrowRight" size={14} /></a>}>
          {streams.length === 0 ? (
            <Empty icon="camera" title={info ? "No cameras yet" : "Connecting to the server…"}
              action={info && can("config:cameras") ? <Button variant="primary" icon="plus" onClick={() => navigateWith("devices", { add: 1 })}>Add a camera</Button> : undefined}>
              {info ? "Add an RTSP or HTTP camera, or a recorded video, to start checking PPE." : undefined}
            </Empty>
          ) : (
            <div className={cx("grid gap-3", streams.length === 1 ? "grid-cols-1" : "grid-cols-1 sm:grid-cols-2")}>
              {streams.map((s) => <CameraTile key={s.id} s={s} onOpen={openCamera} showZones={false} fps={2} />)}
            </div>
          )}
        </Card>

        {canIncidents && (
          <Card title="Needs attention" sub="Newest incidents not reviewed yet" bodyClass="mt-3.5"
            actions={<Button size="sm" onClick={() => navigateWith("incidents", {})}>View all</Button>}>
            {open.failed ? <div className="px-[22px] pb-5"><Notice tone="bad">Couldn't load incidents.</Notice></div>
              : open.items === null ? <div className="space-y-2 px-[22px] pb-5">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-14" />)}</div>
              : open.items.length === 0 ? <Empty icon="check" title="Nothing waiting">Every incident has been reviewed. New ones appear here the moment they are confirmed.</Empty>
              : open.items.map((v) => <IncidentRow key={v.id} v={v} fresh={v.id === open.fresh} />)}
          </Card>
        )}
      </div>

      {/* ---- breakdowns ---- */}
      {canAnalytics && (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
          <Card title="By camera" sub={`Compliance, last 7 days · line marks ${fmtPct(target, 0)}`}>
            {!data ? <Skeleton className="h-40" /> : camRows.length === 0 ? <p className="text-[13px] text-ink-3">No workers were checked in the last 7 days.</p> : (
              <div className="grid gap-3.5">
                {camRows.slice(0, 7).map((c) => (
                  <div key={c.stream_id} className="grid grid-cols-[minmax(0,1fr)_auto] gap-x-3 gap-y-1.5 text-[13.5px]">
                    <b className="truncate font-medium" title={c.stream_name}>{c.stream_name}</b>
                    <span className="num font-mono text-[12.5px] font-medium">{fmtPct(c.compliance_rate)}</span>
                    <div className="relative col-span-2 h-1.5 rounded-[3px] bg-sunken">
                      <i className="block h-full rounded-[3px]" style={{ width: pos(c.compliance_rate!), background: rateColor(c.compliance_rate!, target) }} />
                      <span className="absolute -top-[3px] -bottom-[3px] w-0.5 bg-ink opacity-50" style={{ left: pos(target) }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card title="What's being missed" sub="Incidents by type, last 7 days">
            {!data ? <Skeleton className="h-40" /> : ppeRows.length === 0 ? <p className="text-[13px] text-ink-3">No incidents in the last 7 days.</p> : (
              <div className="grid gap-3">
                {ppeRows.map((p) => (
                  <div key={p.item} className="flex items-center gap-3 text-[13.5px]">
                    <span className="grid size-[30px] shrink-0 place-items-center rounded-lg bg-sunken text-ink-2"><Icon name={ITEM_ICON[p.item] ?? "alert"} size={17} /></span>
                    <div className="min-w-0 flex-1">
                      <span className="block truncate">{violationLabel(p.item)}</span>
                      <span className="mt-1.5 block h-1 overflow-hidden rounded-sm bg-sunken"><i className="block h-full rounded-sm bg-data" style={{ width: `${(p.count / ppeMax) * 100}%` }} /></span>
                    </div>
                    <span className="num font-mono text-[13px] font-medium">{fmtInt(p.count)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card title="When it happens" sub="Incidents by hour and weekday, last 4 weeks">
            {!data ? <Skeleton className="h-40" /> : data.heat.max === 0 ? <p className="text-[13px] text-ink-3">No incidents in the last 4 weeks.</p> : <HourHeat heat={data.heat} />}
          </Card>
        </div>
      )}
    </Page>
  );
}
