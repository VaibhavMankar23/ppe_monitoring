import { useCallback, useMemo, useState } from "react";
import { CameraDrawer } from "../components/live/CameraDrawer";
import { CameraTile } from "../components/live/CameraTile";
import { Page } from "../components/layout/Shell";
import { Button, cx, Empty, Notice, Panel, Segmented, Switch } from "../components/ui";
import { hashParams, navigateWith } from "../lib/router";
import { useAuth } from "../state/auth";
import { useMonitor } from "../state/monitor";

type Layout = "1" | "2" | "3";
const GRID: Record<Layout, string> = {
  "1": "grid-cols-1",
  "2": "grid-cols-1 md:grid-cols-2",
  "3": "grid-cols-1 sm:grid-cols-2 xl:grid-cols-3",
};
const SHOWN: Record<Layout, number> = { "1": 1, "2": 4, "3": Infinity };
const pref = <T extends string>(key: string, fallback: T): T => {
  try { return (localStorage.getItem(key) as T) || fallback; } catch { return fallback; }
};
const save = (key: string, v: string) => { try { localStorage.setItem(key, v); } catch { /* private mode */ } };

/** Layout switch icons: 1×1, 2×2, 3×3. */
function GridIcon({ n }: { n: number }) {
  const g = 18 / n;
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      {Array.from({ length: n * n }, (_, k) => (
        <rect key={k} x={3 + (k % n) * g + 0.75} y={3 + Math.floor(k / n) * g + 0.75} width={g - 1.5} height={g - 1.5} rx={n === 1 ? 2 : 1} />
      ))}
    </svg>
  );
}

type Filter = "all" | "violating" | "offline";

export function LivePage() {
  const { connected, streams, info } = useMonitor();
  const { can } = useAuth();
  const [layout, setLayoutState] = useState<Layout>(() => pref<Layout>("live.layout", "3"));
  const [zones, setZonesState] = useState(() => pref("live.zones", "1") === "1");
  const [filter, setFilter] = useState<Filter>("all");
  const [openId, setOpenId] = useState<string | null>(() => hashParams().get("camera"));
  const open = useCallback((id: string) => setOpenId(id), []);
  const setLayout = (v: Layout) => { setLayoutState(v); save("live.layout", v); };
  const setZones = (v: boolean) => { setZonesState(v); save("live.zones", v ? "1" : "0"); };

  const live = streams.filter((s) => s.status === "live");
  const counts = useMemo(() => ({
    violating: streams.filter((s) => s.violations > 0).length,
    offline: streams.filter((s) => s.status !== "live").length,
  }), [streams]);
  // cameras with someone in violation first, then the configured order
  const wall = useMemo(() => streams
    .filter((s) => (filter === "violating" ? s.violations > 0 : filter === "offline" ? s.status !== "live" : true))
    .sort((a, b) => Number(b.violations > 0) - Number(a.violations > 0))
    .slice(0, SHOWN[layout]), [streams, layout, filter]);
  const matching = filter === "violating" ? counts.violating : filter === "offline" ? counts.offline : streams.length;

  const hasZones = streams.some((s) => s.zones?.length);
  const opened = streams.find((s) => s.id === openId) ?? null;
  const fps = layout === "1" ? 12 : layout === "2" ? 8 : 5;
  const latency = live.length ? Math.round(live.reduce((n, s) => n + s.latency_ms, 0) / live.length) : null;

  return (
    <Page title="Live monitoring" wide
      description={streams.length
        ? `${live.length} of ${streams.length} camera${streams.length === 1 ? "" : "s"} online · detections drawn in real time${latency !== null ? ` · ${latency} ms camera-to-screen` : ""}`
        : "Every camera, as the detector sees it right now."}
      actions={<>
        <div role="radiogroup" aria-label="Layout" className="inline-flex rounded-[10px] border border-line bg-sunken p-[3px]">
          {(["1", "2", "3"] as Layout[]).map((n) => (
            <button key={n} type="button" role="radio" aria-checked={layout === n} aria-label={`${n}×${n} layout`} title={`${n}×${n}`} onClick={() => setLayout(n)}
              className={cx("grid h-[30px] w-9 place-items-center rounded-[7px]", layout === n ? "bg-surface text-ink shadow-[var(--sh-xs)]" : "text-ink-3 hover:text-ink")}>
              <GridIcon n={Number(n)} />
            </button>
          ))}
        </div>
        {can("config:system") && <Button icon="plus" onClick={() => navigateWith("devices", { add: 1 })}>Add camera</Button>}
      </>}
      toolbar={streams.length ? <>
        <Segmented<Filter> label="Show cameras" value={filter} onChange={setFilter} options={[
          { value: "all", label: "All", count: streams.length },
          { value: "violating", label: "Non-compliant", count: counts.violating },
          { value: "offline", label: "Offline", count: counts.offline },
        ]} />
        {hasZones && <div className="ml-auto"><Switch checked={zones} onChange={setZones} label="Show zones" /></div>}
      </> : undefined}>
      {!connected && info && (
        <Notice tone="bad" title="Connection to the server lost" className="mb-4">Figures and video are frozen. Reconnecting automatically.</Notice>
      )}

      {streams.length === 0 ? (
        <Panel>
          <Empty icon="camera" title={info ? "No cameras yet" : "Connecting to the server…"}
            action={info && can("config:system") ? <Button variant="primary" icon="plus" onClick={() => navigateWith("devices", { add: 1 })}>Add the first camera</Button> : undefined}>
            {info ? "Add an RTSP or HTTP camera, or a recorded video, to start checking PPE." : undefined}
          </Empty>
        </Panel>
      ) : wall.length === 0 ? (
        <Panel>
          <Empty icon={filter === "violating" ? "shield" : "check"}
            title={filter === "violating" ? "Nobody is in violation right now" : "Every camera is online"}
            action={<Button onClick={() => setFilter("all")}>Show all cameras</Button>} />
        </Panel>
      ) : (
        <>
          <div className={cx("grid gap-3.5", GRID[layout])}>
            {wall.map((s) => <CameraTile key={s.id} s={s} onOpen={open} showZones={zones} fps={fps} card />)}
          </div>
          {wall.length < matching && (
            <p className="mt-3 text-[12.5px] text-ink-3">
              Showing {wall.length} of {matching} cameras (those with a violation first). Switch to the 3×3 layout to see them all.
            </p>
          )}
        </>
      )}

      <CameraDrawer stream={opened} onClose={() => setOpenId(null)} />
    </Page>
  );
}
