import { useCallback, useEffect, useState } from "react";

export type ThemePref = "system" | "light" | "dark";
const KEY = "ppe-theme";

const read = (): ThemePref => {
  try {
    const v = localStorage.getItem(KEY);
    return v === "light" || v === "dark" ? v : "system";
  } catch {
    return "system";
  }
};

/** Light / dark / follow the OS. index.html applies the saved choice before first paint. */
export function useTheme(): [ThemePref, (p: ThemePref) => void] {
  const [pref, setPref] = useState<ThemePref>(read);
  useEffect(() => {
    const el = document.documentElement;
    if (pref === "system") el.removeAttribute("data-theme");
    else el.setAttribute("data-theme", pref);
    try {
      if (pref === "system") localStorage.removeItem(KEY);
      else localStorage.setItem(KEY, pref);
    } catch { /* private mode: applies to this tab only */ }
  }, [pref]);
  return [pref, useCallback((p: ThemePref) => setPref(p), [])];
}
