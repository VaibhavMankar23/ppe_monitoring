import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { api, jpegDataUrl } from "../../lib/api";
import { fmtTime, violationLabel } from "../../lib/format";
import { href, navigate, navigateWith, ROUTE_PERMISSION, type Route } from "../../lib/router";
import { useTheme } from "../../lib/theme";
import { useAuth } from "../../state/auth";
import { useMonitor } from "../../state/monitor";
import type { Violation } from "../../types";
import { passwordAcceptable, PasswordField, PolicyChecklist } from "../admin/PasswordPolicy";
import { Button, cx, Dialog, Field, Icon, Notice, useToast, type IconName } from "../ui";

type Page = Exclude<Route, "login">;

/** Sidebar navigation (v2): Operate / Configure / Admin. */
const GROUPS: { group: string; items: { route: Page; label: string; icon: IconName }[] }[] = [
  { group: "Operate", items: [
    { route: "overview", label: "Overview", icon: "overview" },
    { route: "monitoring", label: "Live monitoring", icon: "monitoring" },
    { route: "incidents", label: "Incidents", icon: "incidents" },
    { route: "reports", label: "Reports", icon: "reports" },
  ] },
  { group: "Configure", items: [
    { route: "devices", label: "Cameras & zones", icon: "devices" },
    { route: "settings", label: "Detection settings", icon: "sliders" },
  ] },
  { group: "Admin", items: [
    { route: "system", label: "System health", icon: "pulse" },
    { route: "users", label: "Users & roles", icon: "users" },
    { route: "audit", label: "Audit trail", icon: "log" },
  ] },
];
const ITEMS = GROUPS.flatMap((g) => g.items.map((i) => ({ ...i, group: g.group })));
const GROUP_OF = Object.fromEntries(ITEMS.map((i) => [i.route, i.group])) as Record<Page, string>;
const isAdmin = (r: Page) => GROUP_OF[r] !== "Operate";

const RouteCtx = createContext<Page>("overview");

// ------------------------------------------------------------------ shared data

/** Number of incidents nobody has reviewed yet (the Incidents badge). Refreshed on new events and every 30 s. */
function useOpenIncidents(enabled: boolean): number | null {
  const { onViolation } = useMonitor();
  const [n, setN] = useState<number | null>(null);
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    const load = () => api.violations.list({ review: "unreviewed", limit: 1 }).then((p) => alive && setN(p.total)).catch(() => {});
    load();
    const off = onViolation(() => setN((x) => (x === null ? x : x + 1)));
    const t = window.setInterval(load, 30_000);
    return () => { alive = false; off(); window.clearInterval(t); };
  }, [enabled, onViolation]);
  return n;
}

/** Close a popover on outside click / Escape. */
function useDismiss(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) close(); };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") close(); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [open, close]);
  return ref;
}

const HB_ICON = "relative grid size-[38px] place-items-center rounded-[10px] border border-line bg-surface text-ink-2 shadow-[var(--sh-xs)] transition-colors hover:border-line-strong hover:text-ink";
const MENU = "animate-rise absolute top-[calc(100%+8px)] right-0 z-[60] overflow-hidden rounded-[14px] border border-line bg-surface text-ink shadow-pop";

// ------------------------------------------------------------------ notifications

function Bell() {
  const { onViolation } = useMonitor();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Violation[]>([]);
  const [unread, setUnread] = useState(0);
  const close = useCallback(() => setOpen(false), []);
  const ref = useDismiss(open, close);

  useEffect(() => onViolation((v) => {
    setItems((xs) => [v, ...xs.filter((x) => x.id !== v.id)].slice(0, 20));
    setUnread((n) => n + 1);
  }), [onViolation]);

  return (
    <div ref={ref} className="relative">
      <button type="button" className={HB_ICON} aria-label={unread ? `Notifications, ${unread} new` : "Notifications"} aria-expanded={open}
        onClick={() => { setOpen((o) => !o); setUnread(0); }}>
        <Icon name="bell" size={18} />
        {unread > 0 && <span className="absolute top-[7px] right-2 size-2 rounded-full border-2 border-surface bg-brand" />}
      </button>
      {open && (
        <div className={cx(MENU, "w-[min(360px,calc(100vw-24px))]")}>
          <div className="flex items-center gap-2 border-b border-line px-3.5 py-3">
            <b className="text-sm font-semibold">Notifications</b>
            <a href={href("incidents")} onClick={close} className="ml-auto text-[13px] font-medium text-accent hover:underline">Open incidents</a>
          </div>
          {items.length === 0 ? (
            <div className="px-4 py-8 text-center text-[13px] text-ink-3">No new incidents since you signed in. New ones appear here as they are raised.</div>
          ) : (
            <div className="scroll-thin max-h-[400px] overflow-y-auto">
              {items.map((v) => (
                <button key={v.id} type="button" onClick={() => { close(); navigateWith("incidents", { id: v.id }); }}
                  className="grid w-full grid-cols-[auto_minmax(0,1fr)] gap-2.5 border-t border-line px-3.5 py-3 text-left first:border-t-0 hover:bg-surface-2">
                  <img src={jpegDataUrl(v.thumbnail)} alt="" className="size-10 rounded-md bg-stage object-cover" />
                  <span className="min-w-0">
                    <span className="block truncate text-[13.5px] font-semibold">{v.missing.map(violationLabel).join(", ")}</span>
                    <span className="block truncate text-[12.5px] text-ink-3">{v.stream_name} · <span className="num">{fmtTime(v.timestamp)}</span></span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ theme

function ThemeButton() {
  const [pref, setPref] = useTheme();
  const dark = pref === "dark" || (pref === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  return (
    <button type="button" className={HB_ICON} onClick={() => setPref(dark ? "light" : "dark")}
      aria-label={dark ? "Switch to light theme" : "Switch to dark theme"} title={dark ? "Light theme" : "Dark theme"}>
      <Icon name={dark ? "sun" : "moon"} size={18} />
    </button>
  );
}

// ------------------------------------------------------------------ account

function ChangePasswordDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user, changePassword } = useAuth();
  const toast = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const username = user?.username ?? "";
  const differs = next.length > 0 && next !== current;

  useEffect(() => { if (open) { setCurrent(""); setNext(""); setError(null); } }, [open]);

  const submit = async (e?: FormEvent) => {
    e?.preventDefault();
    if (busy) return;
    const problem = !current ? "Enter your current password."
      : !passwordAcceptable(next, username) ? "The new password does not meet the requirements."
      : !differs ? "The new password must be different from the current one." : null;
    if (problem) { setError(problem); return; }
    setBusy(true);
    setError(null);
    try {
      await changePassword(current, next);
      toast({ tone: "success", title: "Password updated", message: "Your other sessions were signed out." });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "The password could not be changed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} title="Change password" width={460}
      footer={<><Button onClick={onClose}>Cancel</Button><Button variant="primary" loading={busy} onClick={() => void submit()}>Update password</Button></>}>
      <form className="grid gap-4" onSubmit={submit} noValidate>
        <p className="text-[13.5px] text-ink-3">Your other sessions are signed out when you save.</p>
        {error && <Notice tone="bad">{error}</Notice>}
        <input type="text" name="username" value={username} autoComplete="username" readOnly hidden />
        <Field label="Current password">{(id) => <PasswordField id={id} value={current} onChange={setCurrent} autoComplete="current-password" autoFocus />}</Field>
        <div>
          <Field label="New password">{(id) => <PasswordField id={id} value={next} onChange={setNext} autoComplete="new-password" />}</Field>
          <PolicyChecklist className="mt-2" password={next} username={username}
            extra={[{ id: "differs", ok: differs, label: "Different from the current password" }]} />
        </div>
        <button type="submit" hidden />
      </form>
    </Dialog>
  );
}


const initials = (name: string) => {
  const parts = name.split(/[._\s-]+/).filter(Boolean);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? parts[0]?.[1] ?? "")).toUpperCase();
};

// ------------------------------------------------------------------ search (Ctrl K)

interface Cmd { id: string; group: string; label: string; hint?: string; icon: IconName; run: () => void }

function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { can } = useAuth();
  const { streams } = useMonitor();
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => { if (open) { setQ(""); setSel(0); queueMicrotask(() => input.current?.focus()); } }, [open]);

  const all = useMemo<Cmd[]>(() => {
    const pages: Cmd[] = ITEMS.filter((i) => can(ROUTE_PERMISSION[i.route])).map((i) => ({
      id: `p-${i.route}`, group: "Pages", label: i.label, hint: i.group, icon: i.icon, run: () => navigate(i.route),
    }));
    const cams: Cmd[] = can("monitor:view") ? streams.map((s) => ({
      id: `c-${s.id}`, group: "Cameras", label: s.name, hint: s.status === "live" ? "Live" : s.running ? s.status : "Stopped", icon: "camera",
      run: () => navigateWith("monitoring", { camera: s.id }),
    })) : [];
    return [...pages, ...cams];
  }, [can, streams]);

  const term = q.trim().toLowerCase();
  const incidentId = /^#?\d+$/.test(term) && can("violations:view") ? Number(term.replace("#", "")) : null;
  const results: Cmd[] = [
    ...(incidentId !== null ? [{ id: "inc", group: "Incidents", label: `Open incident #${incidentId}`, icon: "incidents" as IconName, run: () => navigateWith("incidents", { id: incidentId }) }] : []),
    ...all.filter((c) => !term || c.label.toLowerCase().includes(term) || c.group.toLowerCase().includes(term)),
  ].slice(0, 30);

  useEffect(() => setSel(0), [q]);
  if (!open) return null;
  const run = (c: Cmd | undefined) => { if (!c) return; onClose(); c.run(); };

  let lastGroup = "";
  return (
    <div className="fixed inset-0 z-[70] grid place-items-start justify-items-center overflow-auto bg-[rgb(16_24_40/0.5)] px-4 pt-[10vh]"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label="Search" className="animate-rise w-full max-w-[620px] overflow-hidden rounded-2xl border border-line bg-surface shadow-pop">
        <div className="flex items-center gap-2.5 border-b border-line px-[18px] py-3.5 text-ink-3">
          <Icon name="search" size={18} />
          <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search pages, cameras, or an incident number"
            className="w-full bg-transparent text-base text-ink outline-none placeholder:text-ink-4"
            onKeyDown={(e) => {
              if (e.key === "Escape") onClose();
              else if (e.key === "ArrowDown") { e.preventDefault(); setSel((i) => Math.min(results.length - 1, i + 1)); }
              else if (e.key === "ArrowUp") { e.preventDefault(); setSel((i) => Math.max(0, i - 1)); }
              else if (e.key === "Enter") { e.preventDefault(); run(results[sel]); }
            }} />
        </div>
        <div className="scroll-thin max-h-[380px] overflow-y-auto p-1.5" role="listbox">
          {results.length === 0 && <div className="px-3 py-8 text-center text-[13px] text-ink-3">Nothing matches “{q}”.</div>}
          {results.map((c, i) => {
            const head = c.group !== lastGroup ? (lastGroup = c.group) : null;
            return (
              <div key={c.id}>
                {head && <div className="eyebrow px-3 pt-2.5 pb-1 text-ink-4">{head}</div>}
                <button type="button" role="option" aria-selected={i === sel} onMouseEnter={() => setSel(i)} onClick={() => run(c)}
                  className={cx("flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-left text-sm", i === sel && "bg-accent-soft text-accent")}>
                  <Icon name={c.icon} size={16} />{c.label}
                  {c.hint && <span className="ml-auto text-xs text-ink-3">{c.hint}</span>}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ sidebar

function Sidebar({ route }: { route: Page }) {
  const { user, can, logout } = useAuth();
  const { connected, streams, info } = useMonitor();
  const open = useOpenIncidents(can("violations:view"));
  const [pw, setPw] = useState(false);
  const live = streams.filter((s) => s.status === "live");
  const problems = streams.filter((s) => s.running && s.status !== "live").length;
  const latency = live.length ? Math.round(live.reduce((n, s) => n + s.latency_ms, 0) / live.length) : null;
  const health = !connected ? { tone: "bad", text: "Server unreachable" }
    : problems ? { tone: "warn", text: `${problems} camera${problems === 1 ? "" : "s"} need${problems === 1 ? "s" : ""} attention` }
    : { tone: "ok", text: "All systems normal" };

  return (
    <aside className="no-print z-30 flex flex-col bg-side text-side-ink max-lg:flex-row max-lg:flex-wrap max-lg:items-center max-lg:gap-1.5 max-lg:px-3 max-lg:py-2.5 lg:sticky lg:top-0 lg:h-dvh lg:px-3.5 lg:py-[18px]">
      <a href={href("overview")} aria-label="Mahindra PPE Compliance home" className="flex shrink-0 items-center gap-2.5 px-2 pt-1 text-side-ink no-underline lg:pb-[18px]">
        <img src="/mahindra-logo-on-dark.png" alt="Mahindra" className="h-[22px] w-auto" />
        <span aria-hidden="true" className="h-5 w-px bg-side-3" />
        <b className="text-sm font-semibold tracking-tight">PPE Compliance</b>
      </a>

      <div className="mx-1 mb-[18px] hidden items-center gap-2.5 rounded-xl border border-side-3 bg-side-2 px-3 py-2.5 lg:flex">
        <span className="grid size-[30px] shrink-0 place-items-center rounded-lg bg-[linear-gradient(140deg,#c8102e,#7a0b1c)] text-white"><Icon name="shield" size={16} /></span>
        <span className="min-w-0 leading-tight">
          <b className="block truncate text-[13px] font-semibold">Plant safety monitor</b>
          <span className="text-[11.5px] text-side-ink-2">{streams.length} camera{streams.length === 1 ? "" : "s"} configured</span>
        </span>
      </div>

      <nav aria-label="Main" className="min-h-0 max-lg:order-3 max-lg:-mx-3 max-lg:flex max-lg:w-[calc(100%+24px)] max-lg:gap-0.5 max-lg:overflow-x-auto max-lg:px-2 max-lg:[scrollbar-width:none] lg:flex-1 lg:overflow-y-auto lg:[scrollbar-width:none]">
        {GROUPS.map((g) => {
          const items = g.items.filter((i) => can(ROUTE_PERMISSION[i.route]));
          if (!items.length) return null;
          return (
            <div key={g.group} className="max-lg:contents">
              <div className="px-3 pt-3.5 pb-1.5 text-[11px] font-semibold tracking-[0.08em] text-side-ink-3 uppercase max-lg:hidden">{g.group}</div>
              {items.map((i) => {
                const active = i.route === route;
                const count = i.route === "incidents" ? open : i.route === "monitoring" && streams.length ? `${live.length}/${streams.length}` : null;
                return (
                  <a key={i.route} href={href(i.route)} aria-current={active ? "page" : undefined}
                    className={cx("relative flex items-center gap-[11px] rounded-[9px] px-3 py-[9px] text-[13.5px] font-medium whitespace-nowrap no-underline transition-colors",
                      active ? "bg-side-3 text-white lg:before:absolute lg:before:inset-y-[9px] lg:before:-left-3.5 lg:before:w-[3px] lg:before:rounded-r-[3px] lg:before:bg-brand"
                        : "text-side-ink-2 hover:bg-side-2 hover:text-side-ink")}>
                    <Icon name={i.icon} size={18} />{i.label}
                    {count !== null && count !== 0 && (
                      <span className={cx("ml-auto rounded-full px-[7px] font-mono text-[11px] leading-[18px] font-semibold",
                        i.route === "incidents" ? "bg-brand text-white" : "bg-side-3 text-side-ink")}>{count}</span>
                    )}
                  </a>
                );
              })}
            </div>
          );
        })}
      </nav>

      <div className="mt-3 hidden rounded-xl border border-side-3 bg-side-2 p-3.5 text-[12.5px] lg:block">
        <div className="flex items-center gap-2 pb-1 font-medium text-side-ink">
          <span className={cx("inline-block size-[7px] rounded-full", health.tone === "ok" ? "live-ping bg-[#34d27f]" : health.tone === "warn" ? "bg-[#e9b04f]" : "bg-[#ff6b70]")} />
          {health.text}
        </div>
        <div className="flex justify-between py-[3px] text-side-ink-2"><span>Cameras live</span><b className="num font-medium text-side-ink">{live.length} / {streams.length}</b></div>
        <div className="flex justify-between gap-3 py-[3px] text-side-ink-2"><span>Detector</span><b className="truncate font-medium text-side-ink">{info ? `${info.device} · ${info.imgsz}px` : "–"}</b></div>
        <div className="flex justify-between py-[3px] text-side-ink-2"><span>Latency</span><b className="num font-medium text-side-ink">{latency !== null ? `${latency} ms` : "–"}</b></div>
      </div>

      {user && (
        <div className="flex items-center gap-2.5 px-2 pt-3.5 max-lg:ml-auto max-lg:p-0">
          <span className="grid size-8 shrink-0 place-items-center rounded-full border border-side-3 bg-[linear-gradient(140deg,var(--side-3),var(--side-2))] text-xs font-semibold text-white">{initials(user.username)}</span>
          <span className="min-w-0 flex-1 leading-tight max-lg:hidden">
            <b className="block truncate text-[13px] font-semibold">{user.username}</b>
            <span className="text-[11.5px] text-side-ink-2">{user.role_label}</span>
          </span>
          <button type="button" onClick={() => setPw(true)} title="Change password" aria-label="Change password"
            className="grid size-8 place-items-center rounded-lg border border-side-3 text-side-ink-2 hover:text-side-ink"><Icon name="key" size={15} /></button>
          <button type="button" onClick={() => void logout()} title="Sign out" aria-label="Sign out"
            className="grid size-8 place-items-center rounded-lg border border-side-3 text-side-ink-2 hover:text-side-ink"><Icon name="logout" size={15} /></button>
        </div>
      )}
      <ChangePasswordDialog open={pw} onClose={() => setPw(false)} />
    </aside>
  );
}

// ------------------------------------------------------------------ header

function Clock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => { const t = window.setInterval(() => setNow(new Date()), 1000); return () => window.clearInterval(t); }, []);
  return <span className="num hidden px-1.5 font-mono text-[12.5px] text-ink-3 md:inline">{now.toLocaleTimeString("en-GB")}</span>;
}

function Header() {
  const [search, setSearch] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const bar = useRef<HTMLElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setSearch(true); }
    };
    const onScroll = () => setScrolled(window.scrollY > 4);
    window.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("keydown", onKey); window.removeEventListener("scroll", onScroll); };
  }, []);
  // sticky offsets below the header follow its real height
  useEffect(() => {
    const el = bar.current;
    if (!el) return;
    const ro = new ResizeObserver(() => document.documentElement.style.setProperty("--topbar-h", `${el.offsetHeight}px`));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <header ref={bar} className={cx("no-print sticky top-0 z-20 flex items-center gap-3 border-b px-4 py-3.5 backdrop-blur-md backdrop-saturate-150 sm:px-8",
      "bg-[color-mix(in_srgb,var(--bg)_82%,transparent)]", scrolled ? "border-line" : "border-transparent")}>
      <button type="button" onClick={() => setSearch(true)}
        className="flex h-[38px] max-w-[460px] min-w-0 flex-1 items-center gap-2.5 rounded-[10px] border border-line bg-surface px-3 text-left text-sm text-ink-4 shadow-[var(--sh-xs)] hover:border-line-strong">
        <Icon name="search" size={16} className="text-ink-3" /><span className="flex-1 truncate">Search pages, cameras, incident number…</span>
        <kbd className="hidden rounded-[5px] border border-line-strong px-1.5 font-mono text-[11px] text-ink-3 sm:inline">Ctrl K</kbd>
      </button>
      <div className="ml-auto flex items-center gap-2">
        <Clock />
        <Bell />
        <ThemeButton />
      </div>
      <CommandPalette open={search} onClose={() => setSearch(false)} />
    </header>
  );
}

/** App frame: navy sidebar on the left, a light sticky header, then the page. */
export function Shell({ route, children }: { route: Page; children: ReactNode }) {
  return (
    <RouteCtx.Provider value={route}>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-surface focus:px-3 focus:py-2 focus:shadow-pop">
        Skip to content
      </a>
      <div className="min-h-dvh lg:grid lg:grid-cols-[252px_minmax(0,1fr)]">
        <Sidebar route={route} />
        <div className="flex min-w-0 flex-col">
          <Header />
          <main id="main" tabIndex={-1} className="flex-1 outline-none">{children}</main>
        </div>
      </div>
    </RouteCtx.Provider>
  );
}

/**
 * Standard page frame (v2): eyebrow (the section), a large title, one-line description and actions,
 * optional tabs and toolbar, then the content on the canvas. `flush` removes the content padding.
 */
export function Page({ title, description, actions, toolbar, tabs, children, flush, wide }:
  { title: string; description?: ReactNode; actions?: ReactNode; toolbar?: ReactNode; tabs?: ReactNode; children: ReactNode; flush?: boolean; wide?: boolean }) {
  const route = useContext(RouteCtx);
  const max = wide ? "" : "max-w-[1560px]";
  return (
    <div className="flex min-h-[calc(100dvh-var(--topbar-h))] flex-col">
      <div className={cx("mx-auto w-full px-4 pt-2 sm:px-8", max)}>
        <div className="mt-2.5 mb-6 flex flex-wrap items-end gap-4">
          <div className="min-w-0">
            <div className="mb-1.5 text-[12.5px] text-ink-3">{GROUP_OF[route] ?? ""}</div>
            <h1 className="text-[23px] leading-[1.15] font-semibold tracking-[-0.025em] sm:text-[28px]">{title}</h1>
            {description && <p className="mt-1.5 max-w-3xl text-sm text-ink-3">{description}</p>}
          </div>
          {actions && <div className="no-print ml-auto flex flex-wrap items-center gap-2">{actions}</div>}
        </div>
        {tabs && <div className="no-print mb-[18px] border-b border-line">{tabs}</div>}
        {toolbar && <div className="no-print mb-4 flex flex-wrap items-center gap-2.5">{toolbar}</div>}
      </div>
      <div className={cx("mx-auto min-h-0 w-full flex-1", max, !flush && "px-4 pb-14 sm:px-8")}>
        {children}
      </div>
    </div>
  );
}

// isAdmin kept for pages that render differently inside the Configure / Admin sections
export { isAdmin };
