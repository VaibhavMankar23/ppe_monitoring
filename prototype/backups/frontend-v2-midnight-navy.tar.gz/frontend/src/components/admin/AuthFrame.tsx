import type { ReactNode } from "react";

/**
 * Frame for the screens outside the app shell (sign in, forced password change): a cinematic navy
 * brand panel on the left (hidden on narrow screens), the form on the right.
 */
export function AuthFrame({ title, intro, children, footer }: { title: string; intro?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  return (
    <main id="main" className="grid min-h-dvh bg-surface min-[960px]:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
      <div className="relative hidden flex-col overflow-hidden bg-[#050a12] px-[52px] py-11 text-[#c9d2e0] min-[960px]:flex">
        <div aria-hidden="true" className="absolute inset-0 bg-[radial-gradient(120%_80%_at_0%_100%,rgba(200,16,46,.30),transparent_55%),radial-gradient(90%_70%_at_100%_0%,rgba(31,78,121,.55),transparent_60%)]" />
        <div aria-hidden="true" className="absolute inset-0 opacity-[0.07] [background-image:linear-gradient(rgba(255,255,255,.6)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.6)_1px,transparent_1px)] [background-size:44px_44px]" />
        <div className="relative flex items-center gap-2.5">
          <img src="/mahindra-logo-on-dark.png" alt="Mahindra" className="h-[26px] w-auto" />
          <span aria-hidden="true" className="h-5 w-px bg-[#2a3b57]" />
          <b className="font-semibold text-white">PPE Compliance</b>
        </div>
        <h2 className="relative mt-auto max-w-[15ch] text-[40px] leading-[1.08] font-semibold tracking-[-0.035em] text-white">Every worker. Every shift. Safely home.</h2>
        <p className="relative mt-3.5 mb-8 max-w-[46ch] text-[15px] text-[#9aa8bf]">
          Real-time PPE compliance across the shop floor. Confirmed incidents with evidence, and reviewer verdicts that make the model sharper every week.
        </p>
        <ul className="relative m-0 flex list-none flex-wrap gap-x-8 gap-y-3 p-0 text-[13px] text-[#8c9ab3]">
          {["Confirmed across several frames", "Evidence kept for every incident", "Every action in the audit trail"].map((t) => (
            <li key={t} className="flex items-center gap-2"><span className="size-1.5 rounded-full bg-[#c8102e]" />{t}</li>
          ))}
        </ul>
      </div>
      <div className="grid place-items-center px-6 py-8 sm:py-12">
        <div className="grid w-full max-w-[380px] gap-[18px]">
          <img src="/mahindra-logo.png" alt="Mahindra" className="mb-1 block h-[30px] w-auto justify-self-start dark:brightness-0 dark:invert" />
          <div>
            <h1 className="text-[28px] leading-tight font-semibold tracking-[-0.03em]">{title}</h1>
            {intro && <p className="mt-1.5 text-sm text-ink-3">{intro}</p>}
          </div>
          {children}
          {footer && <p className="m-0 text-[12.5px] text-ink-4">{footer}</p>}
        </div>
      </div>
    </main>
  );
}
